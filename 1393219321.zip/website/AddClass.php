<html>
    <head><title>Add Class</title>
    <link rel="stylesheet" href="webiste.css">
</head>
    <h1>Add Class</h1>
    <style>
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
        </style>
         <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="index1.html">Home</a>
        <div class="dropdown">
            <button class="dropbtn">View 
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="ViewStudent.php">Student</a>
              <a href="ViewTeacher.php">Teacher</a>
              <a href="ViewParent.php">Parent/Guardians</a>
              <a href="ViewClass.php">Classes</a>
              <a href="ViewSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Add
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="AddStudent.php">Student</a>
              <a href="addteacher.php">Teacher</a>
              <a href="addparent.php">Parent/Guardains</a>
              <a href="AddClass.php">Classes</a>
              <a href="AddSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Delete
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="DeleteStudent.php">Student</a>
              <a href="DeleteTeacher.php">Teacher</a>
              <a href="Deleteparent.php">Parents/Guardians</a>
              <a href="DeleteClass.php">Classes</a>
              <a href="DeleteSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Update
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="UpdateStudent.php">Student</a>
              <a href="UpdateTeacher.php">Teacher</a>
              <a href="UpdateParent.php">Parents/Guardians</a>
              <a href="UpdateClass.php">Classes</a>
              <a href="UpdateSalary.php">Salary</a>
          </div> 
        </div>
        
        <a href="Register.php">Register</a>
        <a href="Login.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>
<form 
name="myForm" onsubmit="return validateForm()" method="post" action="AddClass.php">
<label>ClassID:</label>
<input type="classid" name="c1"><br>
<br>
<label>Class Year:</label>
<input type="ClassYear" name="c2"><br>
<br>
<label>Class Room:</label>
<input type="ClassRoom" name="c3"><br>
<br>
<label>Capacity:</label>
<input type="Capacity" name="c4"><br>
<br>
<input type="Submit" name="Submit"><br>
</form>
<?php
 
$link = mysqli_connect("localhost", "root", "", "alphanous1");
 
if ($link === false){
    die("Connection failed:");
}
 
if(isset($_POST['Submit']))
{
    $cid = $_POST['c1'];
    $cnumber = $_POST['c2'];
    $croom = $_POST['c3'];
    $cap = $_POST['c4'];
 
    $sql = "INSERT INTO class (CID,ClassYear,ClassRoom,Capacity) VALUES('$cid','$cnumber','$croom','cap')";
    if (mysqli_query($link, $sql))
    {
        echo "New Record created sucesfully";
    } else
    {
        echo "Error adding record";
    }
}
?>
</body>
</html>
<script>
      function validateForm()
    {
        let x = document.forms["myForm"]["c1"].value;
        let y = document.forms["myForm"]["c2"].value;
        let z = document.forms["myForm"]["c3"].value;
 
        if (x=="")
        {
          alert("ID needs to be fill in");
          return false;
        }else if (x.length > 20) {
        alert("ID must be 20 digits or less");
        return false;
        }
 
        if (y=="")
        {
          alert("Name needs to be fill in");
          return false;
        }else if (y.length > 5) {
        alert("Name needs to be up to 5 characters long");
        return false;
    }
 #
      }
</script>