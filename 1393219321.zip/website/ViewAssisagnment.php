<html>
    <head><title>View Class</title>
    <link rel="stylesheet" href="webiste.css"></head>
    <h1>View Class</h1>
    <body>
    <style>
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
        </style>
    <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="Tindex.html">Home</a>
          <div class="dropdown">
            <button class="dropbtn">Assignment
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="AddAssisagment.php">Add Assignment</a>
              <a href="UpdateAssisagnment.php">Update Assignment</a>
              <a href="ViewAssisagnment.php">View Assisgnment</a>
   
          </div> 
        </div>
        
       
        <a href="Tcontact.php">Contact</a>
        <a href="Tregister.php">Register</a>
        <a href="Tlogin.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>
    </body>
    <?php

$link = mysqli_connect("localhost", "root", "","alphanous1");

if ($link === false){
    die("Connection failed:");
}
?>

<h3>See all Classes</h3>

<table>

<tr>
    <th width="150px">Assignment ID<br><hr></th>
    <th width="250px">Subject<br><hr></th>
    <th width="250px">Date<br><hr></th>
    <th width="250px">File<br><hr></th>
</tr>

<?php
$sql = mysqli_query($link, "SELECT AssignmentID,Subject,Date,File FROM Assignment");
while ($row = $sql->fetch_assoc())
{
    echo "
    <tr>
    <th>{$row['AssignmentID']}</th>
    <th>{$row['Subject']}</th>
    <th>{$row['Date']}</th>
    <th>{$row['File']}</th>
   
    </tr> ";
}

?>

</table>
</body>
</html>