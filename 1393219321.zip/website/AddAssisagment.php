<!DOCTYPE html>
<html lang="en">
    <head>
<meta charset="UTF-8">

</head>
<html>
    <head><title>Add Assisgnment</title>
    <link rel="stylesheet" href="webiste.css">
</head>
    <h1>Add Assissgnment</h1>
    <style>
          .navbar {
    overflow: hidden;
    background-color:Green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  </style>
   <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="Tindex.html">Home</a>
          <div class="dropdown">
            <button class="dropbtn">Assignment
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="AddAssisagment.php">Add Assignment</a>
              <a href="UpdateAssisagnment.php">Update Assignment</a>
              <a href="ViewAssisagnment.php">View Assisgnment</a>
   
          </div> 
        </div>
        
       
        <a href="Tcontact.php">Contact</a>
        <a href="Tregister.php">Register</a>
        <a href="Tlogin.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>

<form 
name="myForm" onsubmit="return validateForm()" method="post" action="AddAssisagment.php">
<label>Assisssgnment ID</label>
<input type="Assignmentid" name="a1"><br>
<br>
<label>Subject:</label>
<input type="Subject" name="a2"><br>
<br>
<label>Date for handin:</label>
<input type="Date" name="a3"><br>
<be>
<label>File:</label>
<input type="File" name="a4" id="file"><br>
<br>
<input type="Submit" name="Submit"><br>
</form>
<?php
 
$link = mysqli_connect("localhost", "root", "", "alphanous1");
 
if ($link === false){
    die("Connection failed:");
}
 
if(isset($_POST['Submit']))
{
    $Aid = $_POST['a1'];
    $subject = $_POST['a2'];
    $date = $_POST['a3'];
    $File = $_POST['a4'];
 
    $sql = "INSERT INTO assisgnmentid (AssignmentID,Subject,Date,file) VALUES('$Aid','$subject','$date','File')";
    if (mysqli_query($link, $sql))
    {
        echo "New Record created sucesfully";
    } else
    {
        echo "Error adding record";
    }
}
?>
</body>
</html>
<script>
      function validateForm()
    {
        let x = document.forms["myForm"]["c1"].value;
        let y = document.forms["myForm"]["c2"].value;
        let z = document.forms["myForm"]["c3"].value;
 
        if (x=="")
        {
          alert("ID needs to be fill in");
          return false;
        }else if (x.length > 20) {
        alert("ID must be 20 digits or less");
        return false;
        }
 
        if (y=="")
        {
          alert("Name needs to be fill in");
          return false;
        }else if (y.length > 5) {
        alert("Name needs to be up to 5 characters long");
        return false;
    }
 #
      }
</script>