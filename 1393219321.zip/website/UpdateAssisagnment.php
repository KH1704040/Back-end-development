<html>
    <head><title>Update Assignment</title>
    <link rel="stylesheet" href="webiste.css"></head>
    <h1>Update Assignment</h1>
    <style>
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
        </style>
        
        <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="Tindex.html">Home</a>
          <div class="dropdown">
            <button class="dropbtn">Assignment
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="AddAssisagment.php">Add Assignment</a>
              <a href="UpdateAssisagnment.php">Update Assignment</a>
              <a href="ViewAssisagnment.php">View Assisgnment</a>
   
          </div> 
        </div>
        
       
        <a href="Tcontact.php">Contact</a>
        <a href="Tregister.php">Register</a>
        <a href="Tlogin.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>

   
        <form method="post" action="UpdateAssisagnment.php">
            <label>Assignment ID:</label>
                <input type="Assignment ID" name="v1"><br>
                <br>

                <label>Subject:</label>
                    <input type="Subject" name="v2"><br>
                    <br>

                    <label>Date:</label>
                    <input type="Date" name="v3"><br>
                    <br>
                    
                    <label>File:</label>
                    <input type="File" name="v4"><br>
                    <br>

        

                    <input type="Submit" name="Submit" value="Update"><br>
</form>
<?php

$link = mysqli_connect("localhost", "root", "", "alphanous1");

if ($link === false){
    die("Connection failed:");
}
if(isset($_POST['Submit']))
{
    $AID = $_POST['v1'];
    $Subject = $_POST['v2'];
    $Date =$_POST['v3'];
    $file =$_POST['v4'];
    

    $sql ="UPDATE Assignment SET Subject ='Subject',Date='$Date', File='$file' WHERE AssignmentID=$AID";
    if ($link->query($sql) === TRUE){
        echo "Record update sucessfully";
    } else {
        echo "Error updating record:" . $link->error;
    }
    $link->close();
}
?>
</body>
</html>