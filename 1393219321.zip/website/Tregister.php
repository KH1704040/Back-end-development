<html>
    <head><title>Teacher register</title>
    <link rel="stylesheet" href="webiste.css"></head>
    <h1>Teacher register</h1>
    <style>
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
        </style>
       <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="index.html">Home</a>
        <div class="dropdown">
</div>

        <a href="Tcontact.php">Contact</a>
        <a href="Tregister.php">Register</a>
        <a href="Tlogin.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>
    </body>

<br>
<?php
$link = mysqli_connect("localhost", "root", "","alphanous1");

if ($link === false)
{
    die("Connection failed:");
}

if(isset($_POST['submit']))
{
    $Username = $_POST['U1'];
    $Email = $_POST['U2'];
    $Password = $_POST['U3'];
    $Create_DateTime = date("Y-m-d H:i:s");
 
    $query = "INSERT INTO tregister (Username,Email,Password,Create_DateTime)
            VALUES('$Username','$Email','" . md5($Password) . "','$Create_DateTime')";
    $result = mysqli_query($link, $query);
    if ($result)
    {
        echo "<div class='form'>
        <h3>You have registered successfully as a Teacher.</h3><br/>
        <p class='link'>Click here to <a href='Tlogin.php'>Login</a></p>
        </div>";
    } else
    {
        echo "<div class='form'>
        <h3>Required fields are missing.</h3><br/>
        <p class='link'>Click here to <a href='Tregister.php'>Register</a></p>
        </div>";
    }


}else{
    ?>
    <form name="myForm" method="post" action="Tregister.php">
<label>UserName:</label>
<input type="username" name="U1"><br>
<br>
<label>Email:</label>
<input type="email" name="U2"><br>
<br>
<label>Password:</label>
<input type="password" name="U3"><br>
<br>

<input type="submit" name="submit"><br>
<?php
}
?>
</form>
</body>
<footer>
<p> this is a Teacher account, Access is limited</p>
<footer>
</html>