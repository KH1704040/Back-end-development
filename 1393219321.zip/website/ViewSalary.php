<html>
    <head><title>View Salary</title>
    <link rel="stylesheet" href="webiste.css"></head>
    <h1>View Salary</h1>
    <body>
    <style>
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
        </style>
  <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="index1.html">Home</a>
        <div class="dropdown">
            <button class="dropbtn">View 
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="ViewStudent.php">Student</a>
              <a href="ViewTeacher.php">Teacher</a>
              <a href="ViewParent.php">Parent/Guardians</a>
              <a href="ViewClass.php">Classes</a>
             <a href="ViewSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Add
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="AddStudent.php">Student</a>
              <a href="addteacher.php">Teacher</a>
              <a href="addparent.php">Parent/Guardains</a>
              <a href="AddClass.php">Classes</a>
               <a href="AddSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Delete
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="DeleteStudent.php">Student</a>
              <a href="DeleteTeacher.php">Teacher</a>
              <a href="Deleteparent.php">Parents/Guardians</a>
              <a href="DeleteClass.php">Classes</a>
              <a href="DeleteSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Update
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="UpdateStudent.php">Student</a>
              <a href="UpdateTeacher.php">Teacher</a>
              <a href="UpdateParent.php">Parents/Guardians</a>
              <a href="UpdateClass.php">Classes</a>
              <a href="UpdateSalary.php">Salary</a>
          </div> 
        </div>
        
        <a href="Register.php">Register</a>
        <a href="Login.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>
    </body>
    <?php

$link = mysqli_connect("localhost", "root", "","alphanous1");

if ($link === false){
    die("Connection failed:");
}
?>

<h3>See all salaries</h3>

<table>

<tr>
    <th width="150px">Salary ID<br><hr></th>
    <th width="250px">Staff Name<br><hr></th>
    <th width="250px">Salary<br><hr></th>
    <th width="250px">address<br><hr></th>
    <th width="250px">Job<br><hr></th>
    <th width="250px">Teacher ID<br><hr></th>
  </tr>

<?php
$sql = mysqli_query($link, "SELECT SID, Sname, Salary,address,Job,TID  FROM salaries");
while ($row = $sql->fetch_assoc())
{
    echo "
    <tr>
    <th>{$row['SID']}</th>
    <th>{$row['Sname']}</th>
    <th>{$row['Salary']}</th>
    <th>{$row['address']}</th>
    <th>{$row['Job']}</th>
    <th>{$row['TID']}</th>
    </tr> ";
}

?>

</table>
</body>
</html>