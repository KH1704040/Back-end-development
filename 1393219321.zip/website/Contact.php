<!DOCTYPE html>
<html lang="en"></html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device=width,initial-scale=1.0">
<link rel="stylesheet" href="webiste.css">
<h1>Contact page</h1>
</head>
<style>
    .navbar {
overflow: hidden;
background-color: green;
}

.navbar a {
float: left;
font-size: 16px;
color: white;
text-align: center;
padding: 14px 16px;
text-decoration: none;
}

.dropdown {
float: left;
overflow: hidden;
}

.dropdown .dropbtn {
font-size: 16px;  
border: none;
outline: none;
color: white;
padding: 14px 16px;
background-color: inherit;
font-family: inherit;
margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
background-color: red;
}

.dropdown-content {
display: none;
position: absolute;
background-color: #f9f9f9;
min-width: 160px;
box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
z-index: 1;
}

.dropdown-content a {
float: none;
color: black;
padding: 12px 16px;
text-decoration: none;
display: block;
text-align: left;
}

.dropdown-content a:hover {
background-color: #ddd;
}

.dropdown:hover .dropdown-content {
display: block;
}

  </style>
 <img src="image/school.jpg.jpg" width="110" height="170">
  <div class="navbar">
    <a href="Sindex.html">Home</a>
  <div class="dropdown">
  </div>
  <a href="Sassissagment.php">Homework</a>
  <a href="Contact.php">Contact</a>
  <a href="Sregister.php">Register</a>
  <a href=SLogin.php>Login</a>
  <a href="Logout.html">Logout</a>
 </div>
<?php
$link = mysqli_connect("localhost", "root", "","alphanous1");

if ($link === false)
{
    die("Connection failed:");
}

if(isset($_POST['submit']))
{
    $Username = $_POST['U1'];
    $Email = $_POST['U2'];
    $Number = $_POST['U3'];
    
 
    $query = "INSERT INTO contact (Name,Email,Phonenumber)
            VALUES('$Username','$Email','$Number')";
    $result = mysqli_query($link, $query);
    if ($result)
    {
        echo "<div class='form'>
        <h3>You have successfully Contacted<br>We aim to get in touch as soon as possible..</h3><br/>
        </div>";
    } else
    {
        echo "<div class='form'>
        <h3>Required fields are missing.</h3><br/>";
        
    }


}else{
    ?>
    <h4>If you wish to contact us,Please fill in the information below.</h4>
    <form name="myForm" method="post" action="Contact.php">
<label>Name:</label>
<input type="username" name="U1"><br>
<br>
<label>Email:</label>
<input type="email" name="U2"><br>
<br>
<label>Phone Number:</label>
<input type="Phone number" name="U3"><br>
<br>
<input type="submit" name="submit"><br>
<?php
}
?>
</form>
</body>
<footer>
<p> this is a Student account, Access is limited</p>
<footer>
</html>