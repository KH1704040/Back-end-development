<html>
    <head><title>View Homework</title>
    <link rel="stylesheet" href="webiste.css"></head>
    <h1>View Homework</h1>
    <body>
    <style>
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
        </style>
 <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="Sindex.html">Home</a>
        <a href=Sassisagment.php>Homework</a>
        <a href="Contact.php">Contact</a>
        <a href="Register.php">Register</a>
        <a href=Login.php>Login</a>
        <a href="Logout.html">Logout</a>
</div>
    </body>
    <?php

$link = mysqli_connect("localhost", "root", "","alphanous1");

if ($link === false){
    die("Connection failed:");
}
?>

<h3>See your Homework</h3>

<table>
<p>Here you can see your assignments that have been handed in.
<tr>
    <th width="150px">Assignment ID<br><hr></th>
    <th width="250px">Subject<br><hr></th>
    <th width="250px">Date<br><hr></th>
    <th width="250px">File<br><hr></th>
</tr>

<?php
$sql = mysqli_query($link, "SELECT AssignmentID,Subject,Date,File FROM Assignment");
while ($row = $sql->fetch_assoc())
{
    echo "
    <tr>
    <th>{$row['AssignmentID']}</th>
    <th>{$row['Subject']}</th>
    <th>{$row['Date']}</th>
    <th>{$row['File']}</th>
   
    </tr> ";
}

?>

</table>
<br>
<br>
<br>
<br>
<p>Please fill the information and hand in your homework students,<br>
on time</p>
<form 
name="myForm" onsubmit="return validateForm()" method="post" action="SAssisagment.php">
<label>Homework ID</label>
<input type="Assignmentid" name="a1"><br>
<br>
<label> Please hand in your homework File:</label>
<input type="File" name="a3" id="file"><br>
<br>
<label> select Assisngment ID and subject :</label>
<br>
                    <select name="Assignment ID">
                    <?php
                      $link = mysqli_connect("localhost", "root", "", "alphanous");
                      
                      if ($link === false){
                          die("Connection failed:");
                      }
                      ?>

                    <?php
                    $sql = mysqli_query($link, "SELECT AssignmentID, Subject FROM Assignment ");
                    while ($row = $sql->fetch_assoc()){
                      echo "<option value='{$row['AssignmentID']}'>
                      {$row['Subject']}
                      {$row['AssignmentID']}
                      </option>";
                    }
                    ?>
                    </select>
                    <br>
                    <br>
                    <input type="submit" name="submit">
                    </form>
                   
<?php

if(isset($_POST['submit']))
{
    $HID = $_POST['a1'];
    $Subject = $_POST['a2'];
    $file = $_POST['a3'];
      $Assignment_id = $_POST['Assignment ID'];
    

    $sql = "INSERT INTO Assignment (HomeworkID,Subject,File,AssignmentID ) VALUES('$HID','$Subject','$file','$Assignment id',)";
    if (mysqli_query($link, $sql))
    {
        echo "New Record created sucesfully";
    } else
    {
        echo "Error adding record";
    }
}
?>


<script>
      function validateForm()
    {
        let x = document.forms["myForm"]["a1"].value;
        let y = document.forms["myForm"]["a2"].value;
        let z = document.forms["myForm"]["a3"].value;
 
        if (x=="")
        {
          alert("ID needs to be fill in");
          return false;
        }else if (x.length > 20) {
        alert("ID must be 20 digits or less");
        return false;
        }
 
        if (y=="")
        {
          alert("Name needs to be fill in");
          return false;
        }else if (y.length > 5) {
        alert("Name needs to be up to 5 characters long");
        return false;
    }
 #
      }
</script>
</body>
</html>