<html>
    <head><title>Add teacher</title>
    <link rel="stylesheet" href="webiste.css">
    <script>
      function validateForm()
    {
        let x = document.forms["myForm"]["u1"].value;
        let y = document.forms["myForm"]["u2"].value;
        let z = document.forms["myForm"]["u3"].value;
 
        if (x=="")
        {
          alert("ID needs to be fill in");
          return false;
        }else if (x.length > 20) {
        alert("ID must be 20 digits or less");
        return false;
        }
 
        if (y=="")
        {
          alert("Name needs to be fill in");
          return false;
        }else if (y.length > 10) {
        alert("Name needs to be up to 5 characters long");
        return false;
    }
 
        if (z=="")
        {
          alert("email needs to be fill in");
          return false;
        }else if (!validateEmail(z)) {
                return false;
            }
 
            return true;
        }
 
        function validateEmail(z) {
            let emailRegex = /\S+@\S+\.\S+/;
 
            if (!emailRegex.test(z)) {
                alert("Please enter the email Adress with the @ symbol.");
                return false;
            }
 
            return true;
      }
</script>
  </head>
    <h1>Add teacher</h1>
    <style>
      
          .navbar {
    overflow: hidden;
    background-color: green;
  }
  
  .navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  
  .dropdown {
    float: left;
    overflow: hidden;
  }
  
  .dropdown .dropbtn {
    font-size: 16px;  
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
  }
  
  .navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
  }
  
  .dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
  }
  
  .dropdown-content a:hover {
    background-color: #ddd;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
        </style>
     <img src="image/school.jpg.jpg" width="110" height="170">
        <div class="navbar">
          <a href="index1.html">Home</a>
        <div class="dropdown">
            <button class="dropbtn">View 
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="ViewStudent.php">Student</a>
              <a href="ViewTeacher.php">Teacher</a>
              <a href="ViewParent.php">Parent/Guardians</a>
              <a href="ViewClass.php">Classes</a>
              <a href="ViewSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Add
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="AddStudent.php">Student</a>
              <a href="addteacher.php">Teacher</a>
              <a href="addparent.php">Parent/Guardains</a>
              <a href="AddClass.php">Classes</a>
              <a href="AddSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Delete
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="DeleteStudent.php">Student</a>
              <a href="DeleteTeacher.php">Teacher</a>
              <a href="Deleteparent.php">Parents/Guardians</a>
              <a href="DeleteClass.php">Classes</a>
              <a href="DeleteSalary.php">Salary</a>
          </div> 
        </div>
        <div class="dropdown">
            <button class="dropbtn">Update
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="UpdateStudent.php">Student</a>
              <a href="UpdateTeacher.php">Teacher</a>
              <a href="UpdateParent.php">Parents/Guardians</a>
              <a href="UpdateClass.php">Classes</a>
              <a href="UpdateSalary.php">Salary</a>
          </div> 
        </div>
        
        <a href="Register.php">Register</a>
        <a href="Login.php">Login</a>
        <a href="Logout.html">Logout</a>
        </div>
    
    <body>
        <form  name="myForm" onsubmit="return validateForm()" method="post" action="addteacher.php">
            <label>TeacherID:</label>
                <input type="Teacherid" name="u1"><br>
                <br>
                <label>Teacher Name:</label>
                    <input type="TeacherName" name="u2"><br>
                    <br>
                    <label>Teacher Email:</label>
                    <input type="TeacherEmail" name="u3"><br>
                    <br>
                    <label>Teacher Address:</label>
                    <input type="TeacherAddress" name="u4"><br>
                    <br>
                    <label>Teacher Phone number :</label>
                    <input type="Teachernumber" name="u5"><br>
                    <br>
                    <label> select class: </label>
                    <select name="ClassID">
                    <?php
                      $link = mysqli_connect("localhost", "root", "", "alphanous1");
                      
                      if ($link === false){
                          die("Connection failed:");
                      }
                      ?>

                    <?php
                    $sql = mysqli_query($link, "SELECT CID, ClassYear FROM class");
                    while ($row = $sql->fetch_assoc()){
                      echo "<option value='{$row['CID']}'>
                      {$row['ClassYear']}
                     
                      </option>";
                    }
                    ?>
                    </select>
                    <br>
                    <br>
                    <input type="Submit" name="Submit">
                    </form>
                   
<?php

if(isset($_POST['Submit']))
{
    $TID = $_POST['u1'];
    $Tname = $_POST['u2'];
    $Temail = $_POST['u3'];
    $Taddress = $_POST['u4'];
    $number = $_POST['u5'];
    $ClassID = $_POST['ClassID'];
  
    $sql = "INSERT INTO teacher (TID,Tname,email,Address,Phonenumber,ClassID) VALUES('$TID','$Tname','$Temail','$Taddress','$number','$ClassID')";
    if (mysqli_query($link, $sql))
    {
        echo "New Record created sucesfully";
    } else
    {
        echo "Error adding record";
    }
}
?>
</body>
</html>